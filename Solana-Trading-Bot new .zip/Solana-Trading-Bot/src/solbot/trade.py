import os, sys, time, logging, base64, requests
from typing import List, Dict, Any, Optional
from dataclasses import dataclass
from solana.rpc.api import Client
from solana.rpc.types import TxOpts
from solders.pubkey import Pubkey
from solders.signature import Signature
from solders.transaction import VersionedTransaction
from dotenv import load_dotenv
from solbot.wallet import WalletManager

load_dotenv()
RPC_URL = os.getenv("SOLANA_RPC_URL")
PRIVATE_KEY = os.getenv("PRIVATE_KEY")

if not RPC_URL or not PRIVATE_KEY:
    logging.critical("Missing SOLANA_RPC_URL or PRIVATE_KEY in .env")
    sys.exit(1)

TOKEN_PROGRAM_ID = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA"
JUPITER_QUOTE = "https://quote-api.jup.ag/v6/quote"
JUPITER_SWAP = "https://quote-api.jup.ag/v6/swap"

BUY_AMOUNT_SOL = 0.025
TAKE_PROFIT = 1.20
STOP_LOSS = 0.978
SCAN_LIMIT = 25
MIN_VOLUME = 1000
MIN_AGE_SECONDS = 600
POLL_INTERVAL = 60

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.FileHandler("auracle_trading.log"), logging.StreamHandler()]
)

@dataclass
class TokenInfo:
    mint: str
    bought_price: float = 0.0
    holding: bool = False

class TradeHandler:
    def __init__(self):
        self.client = Client(RPC_URL)
        self.wallet = WalletManager(PRIVATE_KEY, rpc_url=RPC_URL)
        self.tokens: Dict[str, TokenInfo] = {}

    def get_signatures(self) -> List[str]:
        try:
            resp = self.client.get_signatures_for_address(Pubkey.from_string(TOKEN_PROGRAM_ID), limit=SCAN_LIMIT)
            return [str(sig.signature) for sig in resp.value]
        except Exception as e:
            logging.warning(f"SIG fetch error: {e}")
            return []

    def get_jupiter_quote(self, mint: str) -> Optional[Dict[str, Any]]:
        params = {
            "inputMint": "So11111111111111111111111111111111111111112",
            "outputMint": mint,
            "amount": int(BUY_AMOUNT_SOL * 1e9),
            "slippageBps": 100
        }
        try:
            resp = requests.get(JUPITER_QUOTE, params=params, timeout=10)
            data = resp.json()
            return data.get("data", [None])[0]
        except Exception as e:
            logging.warning(f"Quote API error for {mint[:8]}: {e}")
            return None

    def execute_swap(self, route: Dict[str, Any]) -> Optional[str]:
        try:
            swap_resp = requests.post(JUPITER_SWAP, json={"route": route}, timeout=10)
            swap_resp.raise_for_status()
            swap_tx = swap_resp.json()["swapTransaction"]
            raw = base64.b64decode(swap_tx)
            tx = VersionedTransaction.from_bytes(raw)
            tx.sign([self.wallet.keypair])
            serialized = base64.b64encode(bytes(tx)).decode()
            signature = self.client.send_raw_transaction(serialized, opts=TxOpts(skip_preflight=True, preflight_commitment="finalized"))
            return signature
        except Exception as e:
            logging.error(f"Swap execution failed: {e}")
            return None

    def attempt_buy(self, mint: str):
        route = self.get_jupiter_quote(mint)
        if not route:
            return
        sig = self.execute_swap(route)
        if sig:
            price_per_token = int(route["inAmount"]) / int(route["outAmount"])
            self.tokens[mint] = TokenInfo(mint=mint, bought_price=price_per_token, holding=True)
            logging.info(f"✅ Bought {mint[:8]} @ {price_per_token:.6f} SOL, tx: {sig}")

    def attempt_sell(self, token: TokenInfo):
        route = self.get_jupiter_quote(token.mint)
        if not route:
            return
        current_price = int(route["inAmount"]) / int(route["outAmount"])
        ratio = current_price / token.bought_price
        if ratio >= TAKE_PROFIT or ratio <= STOP_LOSS:
            sig = self.execute_swap(route)
            if sig:
                logging.info(f"💰 Sold {token.mint[:8]} @ {current_price:.6f} SOL (x{ratio:.2f}), tx: {sig}")
                token.holding = False

    def scan_and_trade(self):
        sigs = self.get_signatures()
        for sig_str in sigs:
            try:
                sig = Signature.from_string(sig_str)
                tx = self.client.get_parsed_transaction(sig, encoding="jsonParsed")
                if tx.value:
                    for key in tx.value.transaction.message.account_keys:
                        mint = str(key.pubkey)
                        if mint != TOKEN_PROGRAM_ID and mint not in self.tokens:
                            # Simulated criteria here
                            self.attempt_buy(mint)
            except Exception:
                continue

        # After buys, check holdings for sell
        for token in list(self.tokens.values()):
            if token.holding:
                self.attempt_sell(token)

    def run(self):
        logging.info("🚀 AURACLE is live")
        while True:
            self.scan_and_trade()
            time.sleep(POLL_INTERVAL)

if __name__ == "__main__":
    TradeHandler().run()