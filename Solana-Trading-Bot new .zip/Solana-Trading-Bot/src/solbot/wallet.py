import base58
from solders.keypair import Keypair
from solana.rpc.api import Client
from solana.transaction import Transaction
from solana.rpc.types import TxOpts

class WalletManager:
    def __init__(self, base58_private_key: str, rpc_url: str = "https://api.mainnet-beta.solana.com"):
        self.client = Client(rpc_url)
        key_bytes = base58.b58decode(base58_private_key)
        self.keypair = Keypair.from_bytes(key_bytes)
        self.pubkey = self.keypair.pubkey()

    def send_transaction(self, transaction: Transaction) -> str:
        """Signs and sends a transaction to the network."""
        transaction.sign(self.keypair)
        response = self.client.send_transaction(transaction, self.keypair, opts=TxOpts(skip_preflight=False, skip_confirmation=False))
        if "result" in response:
            return response["result"]
        else:
            raise Exception(f"Transaction failed: {response}")

    def get_balance(self) -> int:
        """Return wallet balance in lamports."""
        balance_resp = self.client.get_balance(self.pubkey)
        if balance_resp["result"]:
            return balance_resp["result"]["value"]
        return 0