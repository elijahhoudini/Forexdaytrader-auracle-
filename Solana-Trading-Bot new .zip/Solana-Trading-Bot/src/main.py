from solbot.trade import TradeHandler

if __name__ == "__main__":
    bot = TradeHandler()
    bot.run()
