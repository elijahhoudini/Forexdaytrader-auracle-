# Paste your Telegram bot token here (from BotFather)
TELEGRAM_BOT_TOKEN = "7661187219:AAHuqb1IB9QtYxHeDbTbnkobwK1rFtyvqvk"
# Your Telegram chat ID - this can be your user ID or your channel/group ID
# To get your chat ID easily, just send a message to your bot, then visit:
# https://api.telegram.org/bot<YOUR_BOT_TOKEN>/getUpdates
# The response JSON will show the chat ID under "message"->"chat"->"id"
TELEGRAM_CHAT_ID = "8009894017"