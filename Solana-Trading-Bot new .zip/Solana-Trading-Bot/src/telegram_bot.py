import requests

class TelegramBot:
    def __init__(self, bot_token: str, chat_id: str):
        self.bot_token = bot_token
        self.chat_id = chat_id
        self.api_url = f"https://api.telegram.org/bot{self.bot_token}"

    def send_message(self, text: str):
        url = f"{self.api_url}/sendMessage"
        data = {"chat_id": self.chat_id, "text": text}
        response = requests.post(url, data=data)
        if response.status_code != 200:
            print(f"Failed to send message: {response.text}")
        return response.json()

    # Optional: You can add receiving commands logic here if you want