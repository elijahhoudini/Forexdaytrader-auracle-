import os
import sys
# ugh https://stackoverflow.com/a/55258233
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))
