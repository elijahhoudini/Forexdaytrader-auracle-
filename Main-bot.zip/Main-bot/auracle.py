
"""
AURACLE: Autonomous AI Solana Trading Bot
========================================

Main system controller and trading loop for Traveler 5798's assistant.
Coordinates all subsystems for autonomous token discovery and trading.
"""

import time
import signal
import sys
import threading
from datetime import datetime
from typing import Dict, Any

# Import AURACLE modules
try:
    from scanner import TokenScanner
    from trade import TradeHandler
    from risk import RiskEvaluator
    from logger import AuracleLogger
    from wallet import Wallet
    from telegram_bot import AuracleTelegramBot
    import config
except ImportError as e:
    print(f"⚠️ Import error: {e}")
    print("Creating mock classes for missing modules...")
    
    # Mock classes for missing modules
    class TokenScanner:
        def scan(self):
            return []
    
    class RiskEvaluator:
        def evaluate(self, token):
            return {"safe": True, "score": 0.5}
    
    class Wallet:
        def get_balance(self, token="SOL"):
            return 1.0
        def send_transaction(self, data):
            return {"success": True, "signature": "mock_tx"}
    
    class AuracleTelegramBot:
        def __init__(self, token, chat_id):
            pass
        def set_auracle_bot(self, bot):
            pass
        def start(self):
            pass

class Auracle:
    """
    Main AURACLE system controller.
    
    Orchestrates autonomous trading operations by coordinating:
    - Token scanning and discovery
    - Risk assessment and fraud detection
    - Trade execution and position management
    - Logging and performance monitoring
    """
    
    def __init__(self):
        """Initialize AURACLE system with all components."""
        print("=" * 60)
        print(f"🚀 INITIALIZING {config.BOT_NAME} v{config.BOT_VERSION}")
        print(f"👤 Traveler ID: {config.TRAVELER_ID}")
        print(f"🤖 Mode: {'Autonomous' if config.AUTONOMOUS_MODE else 'Manual'}")
        print(f"📊 Trading: {config.get_trading_mode_string()}")
        print("=" * 60)
        
        # Initialize core components
        self.logger = AuracleLogger()
        self.wallet = Wallet()
        self.scanner = TokenScanner()
        self.risk = RiskEvaluator()
        self.trade = TradeHandler(self.wallet)
        
        # Initialize Telegram bot if configured
        self.telegram_bot = None
        if config.TELEGRAM_ENABLED and config.TELEGRAM_BOT_TOKEN:
            try:
                self.telegram_bot = AuracleTelegramBot(
                    config.TELEGRAM_BOT_TOKEN, 
                    config.TELEGRAM_CHAT_ID
                )
                self.telegram_bot.set_auracle_bot(self)
                print("✅ Telegram bot initialized")
            except Exception as e:
                print(f"⚠️ Telegram bot initialization failed: {e}")
        
        # System state
        self.running = False
        self.trading_active = True
        self.stats = {
            "scans_completed": 0,
            "tokens_evaluated": 0,
            "trades_executed": 0,
            "start_time": datetime.utcnow()
        }
        
        # Setup signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        print("✅ AURACLE initialization complete")
        self.logger.log_system("AURACLE initialized successfully")

    def run(self):
        """
        Main trading loop - the heart of AURACLE.
        
        Continuously scans for tokens, evaluates risks, and executes trades
        according to the configured strategy and risk parameters.
        """
        self.running = True
        self.logger.log_system("AURACLE main loop starting")
        
        try:
            # Start Telegram bot in separate thread if configured
            if self.telegram_bot:
                telegram_thread = threading.Thread(target=self.telegram_bot.start)
                telegram_thread.daemon = True
                telegram_thread.start()
            
            print("🔄 Starting main trading loop...")
            
            while self.running:
                cycle_start = time.time()
                
                try:
                    # Scan for new token opportunities
                    tokens = self._scan_for_opportunities()
                    
                    # Process each token through our pipeline
                    for token in tokens:
                        if not self.running:
                            break
                            
                        self._process_token(token)
                    
                    # Monitor existing positions
                    self.trade.monitor_positions()
                    
                    # Update statistics
                    self.stats["scans_completed"] += 1
                    
                    # Log performance metrics
                    cycle_duration = time.time() - cycle_start
                    self.logger.log_performance("scan_cycle_duration", cycle_duration, "seconds")
                    
                    # Wait before next cycle
                    sleep_time = max(0, config.SCAN_INTERVAL_SECONDS - cycle_duration)
                    if sleep_time > 0:
                        time.sleep(sleep_time)
                        
                except Exception as e:
                    self.logger.log_error(f"Error in main loop: {str(e)}", {"cycle": self.stats["scans_completed"]})
                    time.sleep(5)  # Short delay before retrying
                    
        except KeyboardInterrupt:
            print("\n🛑 Shutdown requested by user")
        finally:
            self._shutdown()

    def _scan_for_opportunities(self):
        """
        Scan for new trading opportunities.
        
        Returns:
            List[Dict]: List of token opportunities
        """
        try:
            tokens = self.scanner.scan()
            self.stats["tokens_evaluated"] += len(tokens)
            
            if tokens:
                self.logger.log_system(f"Found {len(tokens)} potential opportunities")
            
            return tokens
            
        except Exception as e:
            self.logger.log_error(f"Scanner error: {str(e)}")
            return []

    def _process_token(self, token: Dict[str, Any]):
        """
        Process a single token through the trading pipeline.
        
        Args:
            token (Dict): Token data to process
        """
        try:
            # Step 1: Risk evaluation
            risk_result = self.risk.evaluate(token)
            
            if not risk_result.get("safe", False):
                self.logger.log_flag(
                    token["mint"], 
                    f"Risk assessment failed: {risk_result.get('reason', 'Unknown')}", 
                    token
                )
                return
            
            # Step 2: Trading decision
            if self.trade.should_buy(token) and self.trading_active:
                # Execute buy order
                buy_amount = min(config.MAX_BUY_AMOUNT_SOL, config.POSITION_SIZE_PERCENTAGE)
                
                success = self.trade.buy_token(token, buy_amount)
                
                if success:
                    self.stats["trades_executed"] += 1
                    self.logger.log_trade("BUY", token, buy_amount)
                    
                    # Send Telegram notification if configured
                    if self.telegram_bot:
                        symbol = token.get("symbol", "Unknown")
                        message = f"✅ AURACLE BUY: {symbol} - {buy_amount} SOL"
                        try:
                            self.telegram_bot.send_message(message)
                        except:
                            pass  # Don't let telegram errors stop trading
                else:
                    self.logger.log_trade("BUY_FAILED", token, buy_amount)
                    
        except Exception as e:
            self.logger.log_error(f"Error processing token {token.get('mint', 'unknown')}: {str(e)}")

    def get_status(self) -> Dict[str, Any]:
        """
        Get current system status and performance metrics.
        
        Returns:
            Dict: Current status information
        """
        uptime = datetime.utcnow() - self.stats["start_time"]
        portfolio = self.trade.get_portfolio_summary()
        
        return {
            "status": "running" if self.running else "stopped",
            "trading_mode": config.get_trading_mode_string(),
            "uptime": str(uptime),
            "statistics": self.stats,
            "portfolio": portfolio,
            "configuration": {
                "max_buy_amount": config.MAX_BUY_AMOUNT_SOL,
                "scan_interval": config.SCAN_INTERVAL_SECONDS,
                "profit_target": config.PROFIT_TARGET_PERCENTAGE,
                "stop_loss": config.STOP_LOSS_PERCENTAGE
            }
        }

    def toggle_trading(self) -> bool:
        """
        Toggle trading on/off.
        
        Returns:
            bool: New trading state
        """
        self.trading_active = not self.trading_active
        status = "enabled" if self.trading_active else "disabled"
        self.logger.log_system(f"Trading {status}")
        return self.trading_active

    def _signal_handler(self, signum, frame):
        """Handle system signals for graceful shutdown."""
        print(f"\n🛑 Received signal {signum}, initiating shutdown...")
        self.running = False

    def _shutdown(self):
        """Graceful shutdown procedure."""
        print("\n🔄 Shutting down AURACLE...")
        
        try:
            # Close any open positions if in demo mode
            if config.get_demo_mode():
                for mint in list(self.trade.open_positions.keys()):
                    self.trade.sell_token(mint, "shutdown")
            
            # Log session summary
            session_summary = self.logger.get_session_summary()
            self.logger.log_system("AURACLE session ended", session_summary)
            
            # Final status report
            print("\n📊 Final Session Report:")
            print(f"   Scans Completed: {self.stats['scans_completed']}")
            print(f"   Tokens Evaluated: {self.stats['tokens_evaluated']}")
            print(f"   Trades Executed: {self.stats['trades_executed']}")
            print(f"   Session Duration: {datetime.utcnow() - self.stats['start_time']}")
            
        except Exception as e:
            print(f"⚠️ Error during shutdown: {e}")
        
        finally:
            print("=" * 60)
            print("🤖 AURACLE - Traveler 5798's Assistant - Session Ended")
            print("=" * 60)

def main():
    """
    Main entry point for AURACLE bot.
    
    Validates configuration and starts the trading system.
    """
    try:
        # Validate configuration
        if not config.validate_config():
            print("❌ Configuration validation failed. Please check config.py")
            sys.exit(1)
        
        # Display configuration summary
        print("\n🔧 Configuration Summary:")
        print(f"   Max Buy Amount: {config.MAX_BUY_AMOUNT_SOL} SOL")
        print(f"   Scan Interval: {config.SCAN_INTERVAL_SECONDS} seconds")
        print(f"   Profit Target: {config.PROFIT_TARGET_PERCENTAGE:.1%}")
        print(f"   Stop Loss: {config.STOP_LOSS_PERCENTAGE:.1%}")
        print(f"   Max Daily Trades: {config.MAX_DAILY_TRADES}")
        print()
        
        # Initialize and start AURACLE
        bot = Auracle()
        bot.run()
        
    except Exception as e:
        print(f"❌ Failed to start AURACLE: {str(e)}")
        sys.exit(1)

if __name__ == "__main__":
    main()
