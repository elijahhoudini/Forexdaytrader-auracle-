import time
import requests

print("🟢 AURACLE STARTED")

TELEGRAM_BOT_TOKEN = '7661187219:AAHuqb1IB9QtYxHeDbTbnkobwK1rFtyvqvk'
CHAT_ID = '7661187219'
WALLET_ADDRESS = 'Emac86gtaA1YQg62F8QG5eam7crgD1c1TQj5C8nYHGrr'

def mock_token_scan():
    return [{
        "name": "$LIGHT",
        "address": "TOKEN123",
        "winRate": 0.27,
        "pnl30d": 0.45,
        "tx7d": 120,
        "deployer": "CleanDevAlpha",
        "rugCheck": True,
        "tweetScore": 82
    }]

def auracle_filter(token):
    score = 0
    if token["winRate"] >= 0.25: score += 1
    if token["pnl30d"] >= 0.40: score += 1
    if token["tx7d"] <= 150: score += 1
    if token["rugCheck"]: score += 1
    if token["tweetScore"] >= 70: score += 1
    if "rug" in token["deployer"].lower(): return "flagged"
    return "approved" if score >= 4 else "rejected"

def send_telegram_message(msg):
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": msg}
    response = requests.post(url, data=payload)
    print("📨 SENT TO TELEGRAM:", response.status_code, response.text)

# Main loop
print("🔁 AURACLE LOOP START")
tokens = mock_token_scan()
for token in tokens:
    verdict = auracle_filter(token)
    if verdict == "approved":
        send_telegram_message(f"✅ AURACLE APPROVES: {token['name']}")
    elif verdict == "flagged":
        send_telegram_message(f"⚠️ RISK DETECTED: {token['name']}")
    else:
        print("❌ Token rejected:", token['name'])

print("✅ DONE")
