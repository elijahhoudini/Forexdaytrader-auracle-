
"""
AURACLE Main Entry Point
========================

Simple entry point that starts the AURACLE bot.
"""

if __name__ == "__main__":
    try:
        from auracle import main
        main()
    except ImportError as e:
        print(f"❌ Import error: {e}")
        print("📝 Please ensure all dependencies are installed")
    except KeyboardInterrupt:
        print("\n👋 Bot stopped by user")
    except Exception as e:
        print(f"❌ Error starting AURACLE: {e}")
