"""
AURACLE Logging System
=====================

Comprehensive logging system for trade activities, errors, and system events.
Provides structured logging with multiple output formats and log rotation.
"""

import json
import os
import sys
from datetime import datetime
from typing import Dict, Any, Optional, List
import config

class AuracleLogger:
    """
    Advanced logging system for AURACLE bot operations.
    
    Handles trade logging, error tracking, system events, and performance metrics.
    Supports multiple output formats and automatic log rotation.
    """
    
    def __init__(self):
        """Initialize logger with configuration."""
        self.log_level = config.LOG_LEVEL
        self.log_to_file = config.LOG_TO_FILE
        self.log_to_console = config.LOG_TO_CONSOLE
        self.max_file_size = config.MAX_LOG_FILE_SIZE_MB * 1024 * 1024  # Convert to bytes
        
        # Log file paths
        self.trade_log_file = config.TRADE_LOG_FILE
        self.error_log_file = config.ERROR_LOG_FILE
        self.system_log_file = "data/system_logs.json"
        self.performance_log_file = "data/performance_logs.json"
        
        # Ensure data directory exists
        os.makedirs(config.DATA_DIRECTORY, exist_ok=True)
        
        # Initialize log files
        self._initialize_log_files()
        
        # Session tracking
        self.session_id = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
        self.session_start = datetime.utcnow()
        
        # Performance metrics
        self.metrics = {
            "trades_logged": 0,
            "errors_logged": 0,
            "flags_logged": 0,
            "system_events": 0
        }
        
        self.log_system("AURACLE Logger initialized", {"session_id": self.session_id})
    
    def log_trade(self, action: str, token: Dict[str, Any], amount: float, 
                  additional_data: Optional[Dict[str, Any]] = None):
        """
        Log trading activity with comprehensive details.
        
        Args:
            action (str): Trade action (BUY, SELL, BUY_FAILED, SELL_FAILED)
            token (Dict): Token information
            amount (float): Trade amount in SOL
            additional_data (Dict, optional): Additional trade data
        """
        try:
            # Create comprehensive trade log entry
            trade_entry = {
                "session_id": self.session_id,
                "timestamp": datetime.utcnow().isoformat(),
                "action": action,
                "token": {
                    "mint": token.get("mint", "unknown"),
                    "symbol": token.get("symbol", "unknown"),
                    "name": token.get("name", "unknown")
                },
                "amount_sol": amount,
                "trade_id": f"trade_{self.metrics['trades_logged']:06d}",
                "bot_info": {
                    "name": config.BOT_NAME,
                    "version": config.BOT_VERSION,
                    "traveler_id": config.TRAVELER_ID
                }
            }
            
            # Add additional data if provided
            if additional_data:
                trade_entry["additional_data"] = additional_data
            
            # Add market data if available
            if "liquidity" in token:
                trade_entry["market_data"] = {
                    "liquidity": token.get("liquidity"),
                    "volume_24h": token.get("volume_24h"),
                    "price_change_24h": token.get("price_change_24h"),
                    "holders": token.get("holders")
                }
            
            # Log to file
            if self.log_to_file:
                self._append_json_log(self.trade_log_file, trade_entry)
            
            # Log to console
            if self.log_to_console:
                status = "✅" if "FAILED" not in action else "❌"
                print(f"[TRADE] {status} {action}: {token.get('symbol', '?')} - {amount} SOL")
            
            # Update metrics
            self.metrics["trades_logged"] += 1
            
        except Exception as e:
            self._log_internal_error(f"Trade logging error: {str(e)}")
    
    def log_error(self, error_message: str, context: Optional[Dict[str, Any]] = None,
                  error_type: str = "general"):
        """
        Log error with context and stack trace.
        
        Args:
            error_message (str): Error description
            context (Dict, optional): Additional context
            error_type (str): Error category
        """
        try:
            error_entry = {
                "session_id": self.session_id,
                "timestamp": datetime.utcnow().isoformat(),
                "error_type": error_type,
                "message": error_message,
                "error_id": f"error_{self.metrics['errors_logged']:06d}",
                "context": context or {}
            }
            
            # Log to file
            if self.log_to_file:
                self._append_json_log(self.error_log_file, error_entry)
            
            # Log to console
            if self.log_to_console:
                print(f"[ERROR] {error_type.upper()}: {error_message}")
                if context:
                    print(f"[ERROR] Context: {context}")
            
            # Update metrics
            self.metrics["errors_logged"] += 1
            
        except Exception as e:
            self._log_internal_error(f"Error logging error: {str(e)}")
    
    def log_flag(self, mint: str, reason: str, token_data: Optional[Dict[str, Any]] = None):
        """
        Log risk flag or suspicious activity.
        
        Args:
            mint (str): Token mint address
            reason (str): Reason for flagging
            token_data (Dict, optional): Token information
        """
        try:
            flag_entry = {
                "session_id": self.session_id,
                "timestamp": datetime.utcnow().isoformat(),
                "mint": mint,
                "reason": reason,
                "flag_id": f"flag_{self.metrics['flags_logged']:06d}",
                "token_data": token_data or {}
            }
            
            # Log to file
            if self.log_to_file:
                flag_log_file = "data/flag_logs.json"
                self._append_json_log(flag_log_file, flag_entry)
            
            # Log to console
            if self.log_to_console:
                symbol = token_data.get("symbol", "unknown") if token_data else "unknown"
                print(f"[RISK] 🚩 Flagged {symbol} ({mint[:8]}...): {reason}")
            
            # Update metrics
            self.metrics["flags_logged"] += 1
            
        except Exception as e:
            self._log_internal_error(f"Flag logging error: {str(e)}")
    
    def log_system(self, message: str, data: Optional[Dict[str, Any]] = None):
        """
        Log system events and status messages.
        
        Args:
            message (str): System message
            data (Dict, optional): Additional system data
        """
        try:
            system_entry = {
                "session_id": self.session_id,
                "timestamp": datetime.utcnow().isoformat(),
                "message": message,
                "data": data or {},
                "uptime_seconds": (datetime.utcnow() - self.session_start).total_seconds()
            }
            
            # Log to file
            if self.log_to_file:
                self._append_json_log(self.system_log_file, system_entry)
            
            # Log to console
            if self.log_to_console:
                print(f"[SYSTEM] {message}")
            
            # Update metrics
            self.metrics["system_events"] += 1
            
        except Exception as e:
            self._log_internal_error(f"System logging error: {str(e)}")
    
    def log_performance(self, metric_name: str, value: float, unit: str = ""):
        """
        Log performance metrics.
        
        Args:
            metric_name (str): Name of the metric
            value (float): Metric value
            unit (str): Unit of measurement
        """
        try:
            performance_entry = {
                "session_id": self.session_id,
                "timestamp": datetime.utcnow().isoformat(),
                "metric_name": metric_name,
                "value": value,
                "unit": unit
            }
            
            # Log to file
            if self.log_to_file:
                self._append_json_log(self.performance_log_file, performance_entry)
            
            # Log to console (only for important metrics)
            if self.log_to_console and metric_name in ["scan_duration", "trade_success_rate"]:
                print(f"[PERF] {metric_name}: {value} {unit}")
                
        except Exception as e:
            self._log_internal_error(f"Performance logging error: {str(e)}")
    
    def get_session_summary(self) -> Dict[str, Any]:
        """
        Get summary of current logging session.
        
        Returns:
            Dict: Session summary with metrics
        """
        uptime = datetime.utcnow() - self.session_start
        
        return {
            "session_id": self.session_id,
            "session_start": self.session_start.isoformat(),
            "uptime_seconds": uptime.total_seconds(),
            "uptime_formatted": str(uptime),
            "metrics": self.metrics.copy(),
            "log_files": {
                "trade_log": self.trade_log_file,
                "error_log": self.error_log_file,
                "system_log": self.system_log_file,
                "performance_log": self.performance_log_file
            }
        }
    
    def get_recent_logs(self, log_type: str = "trade", limit: int = 10) -> List[Dict[str, Any]]:
        """
        Get recent log entries.
        
        Args:
            log_type (str): Type of logs to retrieve
            limit (int): Maximum number of entries
            
        Returns:
            List[Dict]: Recent log entries
        """
        log_files = {
            "trade": self.trade_log_file,
            "error": self.error_log_file,
            "system": self.system_log_file,
            "performance": self.performance_log_file
        }
        
        if log_type not in log_files:
            return []
        
        try:
            log_file = log_files[log_type]
            if not os.path.exists(log_file):
                return []
            
            with open(log_file, "r") as f:
                logs = json.load(f)
            
            # Return most recent entries
            return logs[-limit:] if isinstance(logs, list) else []
            
        except Exception as e:
            self._log_internal_error(f"Error retrieving recent logs: {str(e)}")
            return []
    
    def _initialize_log_files(self):
        """Initialize log files with proper structure."""
        log_files = [
            self.trade_log_file,
            self.error_log_file,
            self.system_log_file,
            self.performance_log_file
        ]
        
        for log_file in log_files:
            if not os.path.exists(log_file):
                with open(log_file, "w") as f:
                    json.dump([], f)
    
    def _append_json_log(self, log_file: str, entry: Dict[str, Any]):
        """
        Append entry to JSON log file with rotation.
        
        Args:
            log_file (str): Path to log file
            entry (Dict): Log entry to append
        """
        try:
            # Check file size and rotate if necessary
            if os.path.exists(log_file) and os.path.getsize(log_file) > self.max_file_size:
                self._rotate_log_file(log_file)
            
            # Load existing data
            data = []
            if os.path.exists(log_file):
                with open(log_file, "r") as f:
                    try:
                        data = json.load(f)
                    except json.JSONDecodeError:
                        data = []
            
            # Append new entry
            data.append(entry)
            
            # Write back to file
            with open(log_file, "w") as f:
                json.dump(data, f, indent=2)
                
        except Exception as e:
            self._log_internal_error(f"JSON log append error: {str(e)}")
    
    def _rotate_log_file(self, log_file: str):
        """
        Rotate log file when it gets too large.
        
        Args:
            log_file (str): Path to log file to rotate
        """
        try:
            timestamp = datetime.utcnow().strftime("%Y%m%d_%H%M%S")
            rotated_file = f"{log_file}.{timestamp}"
            
            if os.path.exists(log_file):
                os.rename(log_file, rotated_file)
                print(f"[LOG] Rotated {log_file} to {rotated_file}")
            
        except Exception as e:
            self._log_internal_error(f"Log rotation error: {str(e)}")
    
    def _log_internal_error(self, error_message: str):
        """
        Log internal logging errors to stderr.
        
        Args:
            error_message (str): Error message
        """
        timestamp = datetime.utcnow().isoformat()
        print(f"[LOGGER_ERROR] {timestamp}: {error_message}", file=sys.stderr)
